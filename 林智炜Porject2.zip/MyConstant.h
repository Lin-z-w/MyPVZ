#ifndef MYCONSTANT_H
#define MYCONSTANT_H
extern const int INITRESOURSE;

//HP
extern const int PeaShooterHP, NormalZombieHP, RemoteZombieHP, BallonHP, BigMouthHP;

//Attack Range
extern const int PeaShooterAtRa, NormalZombieAtRa, RemoteZombieAtRa, BallonAtRa, BigMouthAtRa;

//Damage
extern const int PeaShooterDamage, NormalZombieDamage, RemoteZombieDamage, BallonDamage, BigMouthDamage;

#endif // MYCONSTANT_H
