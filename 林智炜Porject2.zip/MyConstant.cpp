#include "MyConstant.h"
const int INITRESOURSE = 100;

//HP
const int PeaShooterHP = 10, NormalZombieHP = 10, RemoteZombieHP = 10, BallonHP = 10, BigMouthHP = 10;


//Attack Range
const int PeaShooterAtRa = 1, NormalZombieAtRa = 1, RemoteZombieAtRa = 3, BallonAtRa = 1, BigMouthAtRa = 1;


//Damage
const int PeaShooterDamage = 5, NormalZombieDamage = 2, RemoteZombieDamage = 1, BallonDamage = 1, BigMouthDamage = 3;
